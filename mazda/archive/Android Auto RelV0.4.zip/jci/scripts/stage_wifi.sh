#!/bin/sh

# Android Auto start
websocketd --port=9999 sh &
